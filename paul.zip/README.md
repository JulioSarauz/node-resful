# Servidor RESTful con nodejs

Recuerda instalar los paquetes

```
npm install
```